<form action="<?php echo e(route('search')); ?>">
  <fieldset>
    <legend>Filtrar por fecha</legend>
    <label for="from">Desde</label>
    <input type="text" name="from" placeholder="Fecha desde">
    <label for="to">Hasta</label>
    <input type="text" name="to" placeholder="Fecha hasta">
    <label for="dev">Seleccionar dispositivo</label>
    <select class="" name="device_id">
      <?php $__currentLoopData = $devices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $device): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($device->id); ?>"><?php echo e($device->name); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <button type="submit" name="button">Filtrar</button>
  </fieldset>
</form>


<?php if(isset($filters)): ?>
<table class="table">
  <thead>
    <tr>
      <th>Destino</th>
      <th>Partida</th>
      <th>Dispositivo</th>
    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $filters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $filter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <td><?php echo e($filter->start_loc); ?></td>
        <br>
        <td><?php echo e($filter->start_date); ?></td>
        <br>
        <td><?php echo e($filter->device_id); ?></td>
      </tr>
      <br/>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
<?php endif; ?>
