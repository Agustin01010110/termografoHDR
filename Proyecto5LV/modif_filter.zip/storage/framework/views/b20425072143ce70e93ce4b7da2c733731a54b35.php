<form action="<?php echo e(route('delivery_store')); ?>">
	<fieldset>
		<legend>Entrega</legend>
		<label for="">Transporte</label>
		<select name="vehicle_id">
			<?php $__currentLoopData = $vehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<option value="<?php echo e($vehicle->id); ?>"><?php echo e($vehicle->name); ?></option>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</select>
		<label for="">Dispositivo</label>
		<select name="device_id" id="">
			<?php $__currentLoopData = $devices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $device): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<option value="<?php echo e($device->id); ?>"><?php echo e($device->name); ?></option>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</select>

		<label for="">Origen</label>
		<input type="text" name="start_loc">
		<label for="">Destino</label>
		<input type="text" name="end_loc">

		<label for="">Hora Inicio</label>
		<input type="text" name="start_date">
		<label for="">Hora Fin</label>
		<input type="text" name="end_date">

		<button type="submit">Enviar</button>

	</fieldset>



</form>

<form action="<?php echo e(route('index')); ?>">
		<button type="submit">Ver</button>
</form>

<form action="<?php echo e(route('filter')); ?>">
		<button type="submit">Filtrar</button>
</form>
