
<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.22.2/moment.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.22.2/locale/es.js"></script>
<script src="https://cdn.jsdelivr.net/npm/lodash@4.17.10/lodash.min.js"></script>
<script src="{{ asset('js/highstock.js')  }}"></script>

<script type="text/javascript">


var data1 = [
    @foreach ($records as $record)
        [
            moment("{{ $record->time }}").format('YYYY-MM-DD HH:mm:ss'),
            {{ $record->temp }}
        ]

      @if (!$loop->last)
          ,
      @endif
    @endforeach
];
var firstdate = new Date( "{{ $records->first()->time }}")
var date = firstdate.getTime()

var hc = Highcharts.stockChart('container',{
    rangeSelector: {
        selected: 2
    },

    title: {
        text: 'Temperatura'
    },

    xAxis: {
        type: 'datetime',
        dateTimeLabelFormats: {
            day: '%e of %b'
        }
    },
    yAxis: {
        floor: -10,
        ceiling: 20,
    },
    series: [{
        name: 'Temperatura',
        pointStart: date,
        pointInterval: 1800 * 1000,
        data: data1,
        tooltip: {
            valueDecimals: 2
        }
    }],

    events:{
      redraw:true
    }
});


</script>
