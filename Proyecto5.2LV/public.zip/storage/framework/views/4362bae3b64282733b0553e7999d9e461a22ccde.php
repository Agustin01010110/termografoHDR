DISPOSITIVOS <br>

<?php if(count($devices)): ?>
<div class="col-sm-6">
  <label for="">Elija el dispositivo</label><br>
    <?php $__currentLoopData = $devices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $device): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <a href="#"><?php echo e($device->name); ?></a> <br>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php else: ?>
    No hay viajes del dispositivo seleccionado <br>
<?php endif; ?>
