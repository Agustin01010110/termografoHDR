<?php $__currentLoopData = $deliveries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $delivery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<div style="background: #777; margin: 20px; padding: 20px; color:white;">

		<b>Servicio:</b> <?php echo e($delivery->start_loc); ?> - <?php echo e($delivery->end_loc); ?> - <?php echo e($delivery->start_date); ?>

		<br>
		<b>Transporte:</b> <?php echo e($delivery->vehicle->name); ?>

		<br>
		<b>Dispositivo:</b> <?php echo e($delivery->device->name); ?>

		<br>
	</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
