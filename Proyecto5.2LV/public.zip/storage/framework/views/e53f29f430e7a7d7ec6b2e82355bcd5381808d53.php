<select name="switch" id="switch">
    <option value="menu1">Camiones</option>
    <option value="menu2">Dispositivos</option>
</select>
<button id="changeMenu">Ver</button>

<div data-menu="menu1">
    <?php echo $__env->make('MonitoringCenter.Elements.list_vehicles',['vehicles'=>$vehicles], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <br>
</div>

<div data-menu="menu2" class="menu-item">
    <?php echo $__env->make('MonitoringCenter.Elements.list_devices',['devices'=>$devices], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>




<?php if(isset($records)): ?>
    <?php if(isset($current_delivery)): ?>

        <div style="text-align:center">
            <h2 style="text-align:center">DATOS PARA ESTE SERVICIO </h2>

            <?php echo $__env->make('MonitoringCenter.Elements.show_dash',['records'=>$records], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
    <?php endif; ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    $(document).ready(function(){
        $('body').on('click','#changeMenu',function(e){
            e.preventDefault();
            e.stopPropagation();

            var current_menu = $('#switch').val();

            $('div[data-menu]')
            .hide()
            .each(function(){
                if($(this).attr('data-menu') == current_menu)
                {
                    $(this).show();
                }
            })
        })
    });
</script>
