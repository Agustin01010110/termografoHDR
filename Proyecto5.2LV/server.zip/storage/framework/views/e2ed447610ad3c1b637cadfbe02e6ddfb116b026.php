<?php if($delivery): ?>
<form action="<?php echo e(route('set-delivery-data')); ?>" method="get">
    <fieldset>
        <legend>ALTA DE SERVICIO</legend>
        <input type="hidden" name="id" value=<?php echo e($delivery->id); ?> >
        <label for="">LUGAR DE ORIGEN</label>
        <input type="text" name="start_loc">
        <label for="">LUGAR DE DESTINO</label>
        <input type="text" name="end_loc">

        <label for="">VEHÍCULO</label>
        <select name="vehicle_id" id="">
            <?php $__currentLoopData = $vehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($vehicle->id); ?>"><?php echo e($vehicle->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <br>
        <br>
        <label for="mode">MODO DE CARGA</label>
        <select name="mode" id="">
          <option value="refrigerado">Refrigerado</option>
          <option value="congelado">Congelado</option>
          <option value="supercongelado">Supercongelado</option>
        </select>
        <label for="sample_time">PERIODO MUESTREO DATOS [min]</label>
        <select name="sample_time" id="">
          <option value="0.5">0.5</option>
          <option value="1">1</option>
          <option value="2">2</option>
          <option value="5">5</option>
        </select>
        <label for="updt_time">PERIODO ACTUALIZACION DATOS [min]</label>
        <select name="updt_time" id="">
          <option value="10">10</option>
          <option value="20">20</option>
          <option value="30">30</option>
          <option value="60">60</option>
        </select>
        
        <button type="submit">GUARDAR</button>
    </fieldset>
</form>
<?php else: ?>
    No hay viajes para este dispositivo

<?php endif; ?>
