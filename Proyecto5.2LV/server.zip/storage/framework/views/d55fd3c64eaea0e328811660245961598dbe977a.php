<?php $__env->startSection('content'); ?>

    <?php if(isset($current_delivery )): ?>
        <h1 style="text-align:center"><?php echo e($current_delivery->service_name); ?></h1>
        <h3 style="text-align:center; color: #777">
            Camion: <?php echo e($current_delivery->vehicle->name); ?> |
            Dispositivo:  <?php echo e($current_delivery->device->name); ?>

        </h3>
    <?php endif; ?>


    <?php if(session()->has('message')): ?>
        <?php echo e(session()->get('message')); ?>

    <?php endif; ?>
    <br>

    <select name="switch" id="switch">
        <option value="menu1">Servicios</option>
        <option value="menu2">Camiones</option>
        <option value="menu3">Dispositivos</option>
    </select>
    <button id="changeMenu">Ver</button>

    <div data-menu="menu1" >
        <?php echo $__env->make('MonitoringCenter.Elements.list_deliveries_working',['activeDeliveries'=>$activeDeliveries], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <br>
    </div>
    <div data-menu="menu3" class="menu-item">
        <?php echo $__env->make('MonitoringCenter.Elements.list_devices_working',['activeDevices'=>$activeDevices], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <br>
    </div>
    <div data-menu="menu3" class="menu-item">

        <?php echo $__env->make('MonitoringCenter.Elements.list_devices_not_working',['devicesNotWorking'=>$devicesNotWorking], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <br>
    </div>
    <div data-menu="menu2" class="menu-item">
        <?php echo $__env->make('MonitoringCenter.Elements.list_vehicles_working',['activeDeliveries'=>$activeDeliveries], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
    <?php if(isset($records)): ?>
        <?php if(isset($current_delivery)): ?>

            <div style="text-align:center">
                <h2 style="text-align:center">DATOS PARA ESTE SERVICIO </h2>
                <?php         $der = ($lastRec->temp - $befLast[0]->temp)/($current_delivery->sample_time); ?>
                <?php echo $__env->make('MonitoringCenter.Elements.show_dash',['records'=>$records, 'sampleInterval' => $current_delivery->sample_time, 'service' => $current_delivery, 'der' => $der], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
        <?php endif; ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>





<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function(){
            $('body').on('click','#changeMenu',function(e){
                e.preventDefault();
                e.stopPropagation();

                var current_menu = $('#switch').val();

                $('div[data-menu]')
                .hide()
                .each(function(){
                    if($(this).attr('data-menu') == current_menu)
                    {
                        $(this).show();
                    }
                })
            })
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>