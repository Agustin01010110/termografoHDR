<?php $__env->startSection('content'); ?>

<form class="col-sm-6" action="<?php echo e(route('fetch-between-dates')); ?>" method="get" onsubmit = "false">

  <fieldset>
    <legend>Historial</legend>
    <h6>Ingrese mes y año del viaje</h6>

    <input type="text" id="datepicker1" />
    <script type="text/javascript">
          $("#datepicker1").datepicker( {
            format: " yyyy", // Notice the Extra space at the beginning
            viewMode: "years",
            minViewMode: "years"
          });
    </script>
    <br>
    <input type="text" id="datepicker2" />
    <script type="text/javascript">
          $("#datepicker2").datepicker( {
            format: "mm", // Notice the Extra space at the beginning
            viewMode: "months",
            minViewMode: "months",
            pickyears: false
          });
    </script>

      <div class="class=col-sm-6">
        <select class="" name="device_id">
            <?php $__currentLoopData = $devices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $device): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($device->id); ?>"><?php echo e($device->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>

      <button type="submit" class="btn btn-primary">Buscar</button>
    </div>
  </fieldset>
</form>





<?php if(isset($deliveries)): ?>
  <?php if(count($deliveries)): ?>
      <?php $__currentLoopData = $deliveries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $delivery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <a href="<?php echo e(route('search-deliveries-for-history', $delivery->id)); ?>"><?php echo e($delivery->start_loc); ?>-<?php echo e($delivery->end_loc); ?>-<?php echo e($delivery->start_date); ?>-<?php echo e($delivery->end_date); ?></a><br>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <?php else: ?>
      El dispositivo no posee historial
  <?php endif; ?>
<?php endif; ?>

<?php if(isset($records)): ?>
  <?php if(count($records)): ?>
    Muestras del viaje:
      <?php echo $__env->make('MonitoringCenter.Elements.show_dash',['records'=>$records], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php else: ?>
      @no  existen registros de ese servicio
  <?php endif; ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>