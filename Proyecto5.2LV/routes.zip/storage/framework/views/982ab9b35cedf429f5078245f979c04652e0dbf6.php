VEHICULOS <br>

<?php if(count($vehicles)): ?>
<div class="col-sm-6">
  <label for="exampleFormControlSelect2">Elija el vehiculo</label>
  <select multiple class="form-control" id="exampleFormControlSelect2">
    <?php $__currentLoopData = $vehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <option><?php echo e($vehicle->name); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </select>
</div>
<?php else: ?>
    No hay viajes del vehiculo seleccionado <br>
<?php endif; ?>
