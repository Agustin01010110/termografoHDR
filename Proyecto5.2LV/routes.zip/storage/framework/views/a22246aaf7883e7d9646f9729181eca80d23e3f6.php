<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.22.2/moment.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.22.2/locale/es.js"></script>
<script src="https://cdn.jsdelivr.net/npm/lodash@4.17.10/lodash.min.js"></script>
<script src="<?php echo e(asset('js/highstock.js')); ?>"></script>
<script src="<?php echo e(asset('js/poll.js')); ?>"></script>


<?php if( count($records) > 0 ): ?>

    <div class="d-flex justify-content-center">
      <div class="col-md-6" id="container">

      </div>
    </div>
    <script type="text/javascript">
    var data1 = [
        <?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            [

                moment("<?php echo e($record->time); ?>").format('YYYY-MM-DD HH:mm:ss'),
                <?php echo e($record->temp); ?>

            ]

          <?php if(!$loop->last): ?>
              ,
          <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    ];
    var lastId = <?php echo e($records->last()->id); ?>

    var startDate = new Date( "<?php echo e($records->first()->time); ?>")
    var endDate = new Date( "<?php echo e($records->last()->time); ?>")
    var date = startDate.getTime()
    var hc = Highcharts.stockChart('container',{
        rangeSelector: {
            selected: 2
        },

        title: {
            text: 'Temperatura'
        },

        xAxis: {
            type: 'datetime',
            dateTimeLabelFormats: {
                day: '%e of %b'
            }
        },
        yAxis: {
            floor: -10,
            ceiling: 20,
        },
        series: [{
            name: 'Temperatura',
            pointStart: date,
            pointInterval: 60 * 1000,
            data: data1,
            tooltip: {
                valueDecimals: 2
            }
        }],

        events:{
          redraw:true
        }
    });
    </script>

<?php else: ?>
    Todavia no hay registros para este viaje.
<?php endif; ?>
