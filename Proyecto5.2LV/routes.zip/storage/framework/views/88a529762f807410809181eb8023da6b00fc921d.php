DISPOSITIVOS PARA DAR DE ALTA <br>
<?php if(count($devicesNotWorking)): ?>
    <?php $__currentLoopData = $devicesNotWorking; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $device): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e(route('fill-delivery-data',$device->id)); ?>"> <?php echo e($device->name); ?> </a> <br>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
    No hay dispositivos para dar de alta <br>
<?php endif; ?>
