<?php if($delivery): ?>

    <form action="<?php echo e(route('set-delivery-data')); ?>" method="get">
        <fieldset>
            <legend>ALTA DE SERVICIO</legend>
            <input type="hidden" name="id" value=<?php echo e($delivery->id); ?> >
            <label for="">LUGAR DE ORIGEN</label>
            <input type="text" name="start_loc">
            <label for="">LUGAR DE DESTINO</label>
            <input type="text" name="end_loc">

            <label for="">VEHÍCULO</label>
            <select name="vehicle_id" id="">
                <?php $__currentLoopData = $vehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($vehicle->id); ?>"><?php echo e($vehicle->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

            <button type="submit">GUARDAR</button>
        </fieldset>
    </form>
<?php else: ?>
    No hay viajes para este dispositivo

<?php endif; ?>
