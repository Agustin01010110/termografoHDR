DISPOSITIVOS TRABAJANDO <br>
<?php if(count($activeDevices)): ?>
    <?php $__currentLoopData = $activeDevices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $device): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href=" <?php echo e(route('monitoring-center-for-device', $device->id)); ?> "><?php echo e($device->name); ?></a> <br>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
    No hay dispositivos activos <br>
<?php endif; ?>
