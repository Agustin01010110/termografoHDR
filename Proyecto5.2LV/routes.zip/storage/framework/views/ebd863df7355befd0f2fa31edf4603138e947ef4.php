CAMIONES ACTIVOS <br>

<?php if(count($activeDeliveries)): ?>
    <?php $__currentLoopData = $activeDeliveries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $delivery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e(route('monitoring-center-for', $delivery->id )); ?>"> <?php echo e($delivery->vehicle->name); ?> </a> <br>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
    No hay camiones activos <br>
<?php endif; ?>
