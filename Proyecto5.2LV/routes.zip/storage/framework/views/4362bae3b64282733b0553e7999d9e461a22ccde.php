DISPOSITIVOS <br>

<?php if(count($devices)): ?>
<div class="col-sm-6">
  <label for="exampleFormControlSelect3">Elija el dispositivo</label>
  <select multiple class="form-control" id="exampleFormControlSelect3">
    <?php $__currentLoopData = $devices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $device): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <option value="<?php echo e($device->id); ?>"><?php echo e($device->name); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </select>
</div>
<?php else: ?>
    No hay viajes del dispositivo seleccionado <br>
<?php endif; ?>
