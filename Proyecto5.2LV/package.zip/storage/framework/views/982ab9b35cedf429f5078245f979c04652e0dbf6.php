VEHICULOS <br>

<?php if(count($vehicles)): ?>
<div class="col-sm-6">
  <label for="">Elija el vehiculo</label><br>
    <?php $__currentLoopData = $vehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <a href="#"> <?php echo e($vehicle->name); ?> </a> <br>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php else: ?>
    No hay viajes del vehiculo seleccionado <br>
<?php endif; ?>
